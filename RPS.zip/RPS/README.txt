How to compile and run: 
    g++ RPS.cpp strat1.cpp
    ./a.out
