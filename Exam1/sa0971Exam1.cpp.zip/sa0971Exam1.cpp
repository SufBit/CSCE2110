//SufyanArshad 
//Sa0971

//Will be using circular linked list
//Will be using insertion sort

#include <iostream>

using namespace std;

class Node{

    public:
        int key; //Get Position of node
        int data; //Store data
        Node* next; //Point to next node

    //default constructor
    Node(){
        key = 0;
        data = 0;
        next = NULL;
    }

    //Paramterized constructor to assign Key and data to node
    Node (int k, int d){

        key = k;
        data =d;

    }
};

class circularLinkedList{

    public:
        Node* head; //Points to the head
    
    circularLinkedList(){

        head = NULL;
    }

    Node* ifNodeExists(int k){

        Node* tempPtr = NULL;
        Node* ptr = head; //Get access to address of head

        if (ptr == NULL){

            return tempPtr;
        }

        else{
            
            //Traverse through the list, with do while as ptr = head.
            do{
                if(ptr ->key == k){//Check if first node key == key we passed

                    tempPtr = ptr;
                }

                ptr = ptr -> next; //Move ptr to next ptr

            }while(ptr != head); //Will end once circle complete.
            return tempPtr;
        }
    }

    //Q1 Add node to list
    void addNode(Node *new_node){

        if(ifNodeExists(new_node->key) != NULL){

            cout << "Key value already present, add another key value" << endl;

        }
        else{

            if (head == NULL){

                head = new_node; //new Node will become head
                new_node ->next = head; //Node will point back to itself
            }

            else{

                Node* ptr = head; //Pointing to first node
                while(ptr -> next!= head){

                    ptr = ptr -> next;
                }

                ptr -> next = new_node; //ptr next points to new node
                new_node -> next = head;// NewNode points back to head
                cout << "Node added" <<endl;
                 
            }
        }
    }

    //deleting a node
    void deleteANode(int k){

    Node * ptr = ifNodeExists(k);
    if (ptr == NULL) {
      cout << "No node exists with key value OF : " << k <<
        endl;
    } else {

      if (ptr == head) {
        if (head -> next == NULL) {
          head = NULL;
          cout << "Head node Unlinked... List Empty";
        } else {
          Node * ptr1 = head;
          while (ptr1 -> next != head) {
            ptr1 = ptr1 -> next;
          }
          ptr1 -> next = head -> next;
          head = head -> next;
          cout << "Node UNLINKED with keys value : " << k << endl;
        }
      } else {
        Node * temp = NULL;
        Node * prevptr = head;
        Node * currentptr = head -> next;
        while (currentptr != NULL) {
          if (currentptr -> key == k) {
            temp = currentptr;
            currentptr = NULL;
          } else {
            prevptr = prevptr -> next;
            currentptr = currentptr -> next;
          }
        }

        prevptr -> next = temp -> next;
        cout << "Node UNLINKED with keys value : " << k << endl;

      }

    }

        


    }

void printList() {
    if (head == NULL) {
      cout << "No Nodes in Circular Linked List";
    } else {
      cout << endl << "head address : " << head << endl;
      cout << "Circular Linked List Values : " << endl;

      Node * tempPtr = head;

      do {
        cout << "(" << tempPtr -> key << "," << tempPtr -> data << "," << tempPtr-> next << ") --> ";
        tempPtr = tempPtr -> next;
      } while (tempPtr != head);
    }

  }

};

int main(){

    circularLinkedList Object;
    int chooseMenu;
    int key1, k1, data1;

    do{
    cout << "What Would you like to do?" << endl;
        cout << "0. to exit" << endl;
        cout << "1. appendNode()" << endl;
        cout << "2. deleteNodeByKey()" << endl;
        cout << "3. print()" << endl;

    cin >> chooseMenu;
    Node * n1 = new Node();
    //Node n1;

    switch (chooseMenu) {
    case 0:
      break;
    case 1:
      cout << "Append Node Operation \nEnter key & data of the Node to be Appended" << endl;
      cin >> key1;
      cin >> data1;
      n1 -> key = key1;
      n1 -> data = data1;
      Object.addNode(n1);
      break;
    case 2:

      cout << "Delete Node By Key Operation - \nEnter key of the Node to be deleted: " << endl;
      cin >> k1;
      Object.deleteANode(k1);
      break;
     case 6:
      Object.printList();
      break;

    }
    }while (chooseMenu != 0);

    return 0;
}